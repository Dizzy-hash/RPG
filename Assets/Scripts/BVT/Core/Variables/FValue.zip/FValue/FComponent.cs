﻿using UnityEngine;
using System.Collections;

namespace BVT.Core
{
    public class FComponent : FValue
    {
        public Component V;

        public override object GetValue()
        {
            return V;
        }

        public override void   SetValue(object v)
        {
            this.V = (Component)v;
        }

        public override void   DrawField()
        {
#if UNITY_EDITOR
            V = (Component)UnityEditor.EditorGUILayout.ObjectField("", V, typeof(Component), true, GUILayout.MaxWidth(100), GUILayout.ExpandWidth(true));
#endif
        }
    }
}
