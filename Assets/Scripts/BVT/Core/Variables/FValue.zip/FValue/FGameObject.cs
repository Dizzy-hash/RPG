﻿using UnityEngine;
using System.Collections;

namespace BVT.Core
{
    public class FGameObject : FValue
    {
        public GameObject V;

        public override object GetValue()
        {
            return V;
        }

        public override void   SetValue(object v)
        {
            this.V = (GameObject)v;
        }

        public override void   DrawField()
        {
#if UNITY_EDITOR
            V = (GameObject)UnityEditor.EditorGUILayout.ObjectField("", V, typeof(GameObject), true, GUILayout.MaxWidth(100), GUILayout.ExpandWidth(true));
#endif
        }
    }
}
