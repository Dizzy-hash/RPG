﻿using UnityEngine;
using System.Collections;

namespace BVT.Core
{
    public class FVector2 : FValue
    {
        public Vector2 V;

        public override object GetValue()
        {
            return V;
        }

        public override void   SetValue(object v)
        {
            this.V = (Vector2)v;
        }

        public override void   DrawField()
        {
#if UNITY_EDITOR
            V = UnityEditor.EditorGUILayout.Vector2Field("", V, GUILayout.MaxWidth(100), GUILayout.ExpandWidth(true));
#endif
        }
    }
}
