﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;

namespace BVT.Core
{
    public class FGameObjectList : FValue
    {
        public List<GameObject> V = new List<GameObject>();

        public override object GetValue()
        {
            return V;
        }

        public override void   SetValue(object v)
        {
            this.V = (List<GameObject>)v;
        }

        public override void   DrawField()
        {
#if UNITY_EDITOR

#endif
        }
    }
}
