﻿using UnityEngine;
using System.Collections;

namespace BVT.Core
{
    public class FBool : FValue
    {
        public bool V;

        public override object GetValue()
        {
            return V;
        }

        public override void   SetValue(object v)
        {
            this.V = (bool)v;
        }

        public override void   DrawField()
        {
#if UNITY_EDITOR
            V = UnityEditor.EditorGUILayout.Toggle(V, GUILayout.MaxWidth(100), GUILayout.ExpandWidth(true));
#endif
        }
    }
}
