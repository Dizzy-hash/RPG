﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using UnityEngine;

namespace BVT.Core
{
    public class FVector3 : FValue
    {
        public Vector3 V;

        public override object GetValue()
        {
            return V;
        }

        public override void   SetValue(object v)
        {
            this.V = (Vector3)v;
        }

        public override void   DrawField()
        {
#if UNITY_EDITOR
            V = UnityEditor.EditorGUILayout.Vector3Field("", V, GUILayout.MaxWidth(100), GUILayout.ExpandWidth(true));
#endif
        }
    }
}
