﻿using UnityEngine;
using System.Collections;

namespace BVT.Core
{
    public class FColor : FValue
    {
        public Color V;

        public override object GetValue()
        {
            return V;
        }

        public override void   SetValue(object v)
        {
            this.V = (Color)v;
        }

        public override void   DrawField()
        {
#if UNITY_EDITOR
            V = UnityEditor.EditorGUILayout.ColorField(V, GUILayout.MaxWidth(100), GUILayout.ExpandWidth(true));
#endif
        }
    }
}
