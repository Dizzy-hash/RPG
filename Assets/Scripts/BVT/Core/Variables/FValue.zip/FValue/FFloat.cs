﻿using UnityEngine;
using System.Collections;

namespace BVT.Core
{
    public class FFloat : FValue
    {
        public float V;

        public override object GetValue()
        {
            return V;
        }

        public override void   SetValue(object v)
        {
            this.V = (float)v;
        }

        public override void   DrawField()
        {
#if UNITY_EDITOR
            GUI.backgroundColor = new Color(0.7f, 0.7f, 1);
            V = UnityEditor.EditorGUILayout.FloatField(V, GUILayout.MaxWidth(100), GUILayout.ExpandWidth(true));
#endif
        }
    }
}
