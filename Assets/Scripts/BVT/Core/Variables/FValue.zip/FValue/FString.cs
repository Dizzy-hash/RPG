﻿using UnityEngine;
using System.Collections;

namespace BVT.Core
{
    public class FString : FValue
    {
        [SerializeField]
        public string V = string.Empty;

        public override object GetValue()
        {
            return V;
        }

        public override void   SetValue(object v)
        {
            this.V = (string)v;
        }

        public override void   DrawField()
        {
#if UNITY_EDITOR
            GUI.backgroundColor = new Color(0.5f, 0.5f, 0.5f);
            V = UnityEditor.EditorGUILayout.TextField(V, GUILayout.MaxWidth(100), GUILayout.ExpandWidth(true));
#endif
        }
    }
}