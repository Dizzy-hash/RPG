﻿using UnityEngine;
using System.Collections;
using System;

namespace BVT.Core
{
    public class FInt : FValue
    {
        public int V;

        public override object GetValue()
        {
            return V;
        }

        public override void   SetValue(object v)
        {
            this.V = (int)v;
        }

        public override void   DrawField()
        {
#if UNITY_EDITOR
            GUI.backgroundColor = new Color(0.7f, 1, 0.7f);
            V = UnityEditor.EditorGUILayout.IntField(V, GUILayout.MaxWidth(100), GUILayout.ExpandWidth(true));
#endif
        }
    }
}

